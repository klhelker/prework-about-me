document.getElementById("button1").addEventListener("click", function(){

    document.getElementById("box").style.height = "200%";});

    document.getElementById("button2").addEventListener("click", function(){
  
        document.getElementById("box").style.color = "blue";});

    document.getElementById("button3").addEventListener("click", function(){

        document.getElementById("box").style.height = "25px";});

    document.getElementById("button4").addEventListener("click", function(){

        document.getElementById("box").style.height = "150x";

    });

    
